﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication32
{
    class Produkt : ICloneable
    {
        private string nazwa;
        private int cena;
        private int ilosc;
        public Produkt()
        {
           
        }
        public Produkt(string nazwa, int cena, int ilosc)
        {
            this.nazwa = nazwa;
            this.cena = cena;
            this.ilosc = ilosc;
        }
        public int podajCene()
        {
            return ilosc * cena;
        }
        public string podajNazwe()
        {
            return nazwa;
        }
        public
        Object Clone() 
        {
            return MemberwiseClone();
        }
    }
}
