﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication32
{
    class Aplikacja : Koszyk
    {
        public char klawisz;

        public void WypiszLegende()
        {
            Console.Write("Dzień Dobry!\n");
            Console.WriteLine("Co Chcesz zrobić? Naciśnij odpowiedni klawisz.\n");
            Console.WriteLine("Legenda:\n");
            Console.WriteLine("P - dodaj produkt do koszyka\n");
            Console.WriteLine("K - skopiuj ostatnio wprowadzony produkt\n");
            Console.WriteLine("Z - pokaz zawartość koszyka");
            Console.WriteLine("S - pokaz Sumę do zapłaty");
            Console.WriteLine("X - skasuj produkt z listy (musisz znać wcześniej numer na liście");
            Console.WriteLine("W - wydrukuj paragon");
            Console.WriteLine("E - Zakończ program");
        }
        public void WczytajKlawisz()
        {
           klawisz = Convert.ToChar(Console.ReadLine());
            // klawisz = Console.ReadKey().KeyChar;

             
        }
        public void WykonajDzialanie()
        {
            switch (klawisz)
            {
                case 'P':
                     Produkt zakup = new Produkt("banan", 2, 3);
                   // Koszyk kupic = new Koszyk();
                     break;
                case 'K':

                    break;
                case 'Z':
                    

                    break;
                case 'S':
                    break;
            }
        }
    }
}
