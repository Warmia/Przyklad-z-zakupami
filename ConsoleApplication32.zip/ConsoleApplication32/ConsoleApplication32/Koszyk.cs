﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication32
{
    class Koszyk 
    {
        public  Produkt[] zakupy = new Produkt[25]; 
        private int cena;
        private int ilosc_elementow;

        public void włóżDoKoszyka(Produkt przedmiot)
        {
            zakupy[ilosc_elementow++] = przedmiot; 
            cena += przedmiot.podajCene();
        }
        public int podajCeneKoszyka()
        {
            return cena;
            
        }

        public void podajZawartoscKoszyka()
        {
            for (int i = 0; i < ilosc_elementow; i++)
                Console.WriteLine((i + 1) + ": Nazwa: " + zakupy[i].podajNazwe() + ", cena: " + zakupy[i].podajCene());
        }
        
    }
}
